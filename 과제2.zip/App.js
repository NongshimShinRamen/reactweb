const [todos, setTodos] = useState([
  {
    id: 1,
    text: '리액트 기초 알아보기',
    checked: true,
  },
  {
    id: 2,
    text: '컴포넌트 스타일링 하기',
    checked: true,
  },
  {
    id: 3,
    text: '투두리스트 만들기',
    checked: false,
  },
]);

<TodoList
todos={todos}
/>

const nextId = useRef(4);
  const onInsert = useCallback(
    (text) => {
      const todo = {
        id: nextId.current,
        text,
        checked: false,
      };
      setTodos(todos.concat(todo)); //concat(): 인자로 주어진 배열이나 값들을 기존 배열에 합쳐서 새 배열 반환
      nextId.current++; //nextId 1씩 더하기
    },
    [todos],
  );

  <ToDoInsert onInsert={onInsert} />


  const onRemove = useCallback(
    (id) => {
      setTodos(todos.filter((todo) => todo.id !== id));
    },
    [todos],
  );

  const onToggle = useCallback(
    (id) => {
      setTodos(
        todos.map((todo) =>
          todo.id === id ? { ...todo, checked: !todo.checked } : todo,
        ),
      );
    },
    [todos],
  );

  




  const [insertToggle, setInsertToggle] = useState(false); //플래그 역할을 해줄 state



  return (
    <TodoTemplate>
		
     	
      	
      {insertToggle && (
        <ToDoEdit />
      )}
    </TodoTemplate>
  );


  const onUpdate = (id, text) => {
    onInsertToggle();
    
    setTodos(todos.map((todo) => (todo.id === id ? { ...todo, text } : todo)));
  };