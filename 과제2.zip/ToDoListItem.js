function ToDoListItem({ todo }) {
    const { id, text, checked } = todo;
    return (
      <li className="TodoListItem">
        <div className={cn('checkbox', { checked })}>
          
          {checked ? <MdCheckBox /> : <MdCheckBoxOutlineBlank />}
         
          <div className="text">{text}</div>
        </div>
        <div className="edit">
          <MdModeEditOutline />
        </div>
        <div className="remove">
          <MdRemoveCircleOutline />
        </div>
      </li>
    );
  }

  function ToDoListItem({ todo, onRemove }) {
    const { id, text, checked } = todo;
    return (
      <li className="TodoListItem">
        <div className={cn('checkbox', { checked:checked })}>
          {checked ? <MdCheckBox /> : <MdCheckBoxOutlineBlank />}
          <div className="text">{text}</div>
        </div>
        <div className="edit">
          <MdModeEditOutline />
        </div>
        <div className="remove" onClick={() => onRemove(id)}>
          <MdRemoveCircleOutline />
        </div>
      </li>
    );
  }

  return (
    <li className="TodoListItem">
		
      	
      <div className="edit" onClick={() =>
        {onChangeSelectedTodo(todo)
          onInsertToggle();
        }
         }>
        <MdModeEditOutline />
      </div>
		
      	
    </li>
  );



  useEffect(() => {
    if (selectedTodo) {
      setValue(selectedTodo.text);
    }
  }, [selectedTodo]);

  return (
    <div className="background">
      <form onSubmit={onSubmit} className="todoedit__insert">
        <h2>수정하기</h2>
        <input
          onChange={onChange}
          value={value}
          placeholder="할 일을 입력하세요"
        />
        <button type="submit">수정하기</button>
      </form>
    </div>
  );

  